package com.example.flutter_simple_page;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
