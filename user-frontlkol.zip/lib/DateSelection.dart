import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import 'TimeSelection.dart';

class DateSelection extends StatefulWidget {
  final String terrainId;

  DateSelection(this.terrainId);

  @override
  _DateSelectionState createState() => _DateSelectionState();
}

class _DateSelectionState extends State<DateSelection> {
  late DateTime _selectedDate;

  @override
  void initState() {
    super.initState();
    _selectedDate = DateTime.now();
  }

  Future<void> _selectDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: _selectedDate,
      firstDate: DateTime.now(),
      lastDate: DateTime.now().add(Duration(days: 30)),
      builder: (BuildContext context, Widget? child) {
        return Theme(
          data: ThemeData.light().copyWith(
            primaryColor: Colors.green,
            accentColor: Colors.green,
            colorScheme: ColorScheme.light(
              primary: Colors.green,
              secondary: Colors.green,
            ),
            buttonTheme: ButtonThemeData(
              textTheme: ButtonTextTheme.primary,
            ),
          ),
          child: child!,
        );
      },
    );
    if (picked != null && picked != _selectedDate) {
      setState(() {
        _selectedDate = picked;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Choose Date'),
        backgroundColor: Colors.green,
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              widget.terrainId,
              style: TextStyle(fontSize: 20),
            ),
            Text(
              'Selected Date:',
              style: TextStyle(fontSize: 20),
            ),
            SizedBox(
              height: 10,
            ),
            Text(
              '${DateFormat('dd/MM/yyyy').format(_selectedDate)}',
              style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold),
            ),
            SizedBox(
              height: 30,
            ),
            ElevatedButton.icon(
              onPressed: () => _selectDate(context),
              icon: Icon(Icons.date_range),
              style: ElevatedButton.styleFrom(primary: Colors.green),
              label: Text('Choose Date'),
            ),
            SizedBox(
              height: 30,
            ),
            FloatingActionButton.extended(
              onPressed: () {
                Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => TimeSelection(_selectedDate,widget.terrainId),
                    ));
              },
              label: Text('Next'),
             backgroundColor: Colors.green,
              icon: Icon(Icons.navigate_next_rounded),
            ),
          ],
        ),
      ),
    );
  }
}
