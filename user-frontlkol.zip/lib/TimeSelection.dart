import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

class TimeSelection extends StatefulWidget {
  final String terrainId;
  final DateTime date;

  TimeSelection(this.date,this.terrainId);
  @override
  _TimeSelectionState createState() => _TimeSelectionState();
}

class _TimeSelectionState extends State<TimeSelection> {
  late int _selectedTime;

  @override
  void initState() {
    super.initState();
    _selectedTime = 16;
  }

  void _onTimeSelected(int time) {
    setState(() {
      _selectedTime = time;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Choose Time'),
        backgroundColor: Colors.green,
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
             Text(
              widget.terrainId,
              style: TextStyle(fontSize: 20),
            ),
            Text(
              DateFormat('yyyy-MM-dd').format(widget.date),
              style: TextStyle(fontSize: 20),
            ),
            const Text(
              'Selected Time:',
              style: TextStyle(fontSize: 20),
            ),
            const SizedBox(
              height: 10,
            ),
            Text(
              '${_selectedTime.toString().padLeft(2, '0')}:00',
              style: const TextStyle(fontSize: 25, fontWeight: FontWeight.bold),
            ),
            const SizedBox(
              height: 30,
            ),
            const Text(
              'Select a time slot:',
              style: TextStyle(fontSize: 20),
            ),
            const SizedBox(
              height: 10,
            ),
            Wrap(
              alignment: WrapAlignment.center,
              spacing: 20,
              children: [
                for (int i = 15; i <= 24; i += 2)
                  GestureDetector(
                    onTap: () => _onTimeSelected(i),
                    child: Container(
                      padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 20),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(10),
                        color: _selectedTime == i ? Colors.green : Colors.grey[300],
                      ),
                      child: Text(
                        '${i.toString().padLeft(2, '0')}:00',
                        style: TextStyle(
                          fontSize: 20,
                          fontWeight: _selectedTime == i ? FontWeight.bold : FontWeight.normal,
                          color: _selectedTime == i ? Colors.white : Colors.black,
                        ),
                      ),
                    ),
                  ),

              ],
            ),
            const SizedBox(
              height: 30,
            ),
            FloatingActionButton.extended(
              onPressed: () {

              },
              backgroundColor: Colors.green,
              label: Text('Confirm'),
              icon: Icon(Icons.check_circle),
            ),
          ],
        ),
      ),
    );
  }
}
